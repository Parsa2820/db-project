Run with:
```
python manage.py runserver
```